package com.example.aiplugin;

import org.bukkit.command.CommandSender;

public class AIUtils {
    public static void send(CommandSender s, String msg) { s.sendMessage(msg); }
}
