#!/bin/bash
# Example deploy script: copy built plugin to remote server via scp
# Requires: SSH key access configured, REMOTE_USER, REMOTE_HOST, REMOTE_PATH env vars set.
JAR=$(ls target/*.jar | head -n1)
if [ -z "$JAR" ]; then
  echo "No JAR found in target/"
  exit 1
fi
scp "$JAR" "$REMOTE_USER@$REMOTE_HOST:$REMOTE_PATH"
echo "Deployed $JAR to $REMOTE_HOST:$REMOTE_PATH"
